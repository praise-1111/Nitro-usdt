const dd = document.getElementsByClassName("datas")[0];
document.addEventListener(
  "touchstart",
  function (event) {
    if (event.touches.length > 1) {
      event.preventDefault();
    }
  },
  { passive: false }
);
document.addEventListener("gesturestart", function (e) {
  e.preventDefault();
});

function notify(n, t) {
  setTimeout(() => {
    nn.classList.remove("animate");
  }, 2000);

  const nn = document.querySelector("#notifications");

  if (!n) {
    nn.style.backgroundColor = "#d42a1e";
  } else {
    nn.style.backgroundColor = "rgb(11, 97, 11)";
  }

  nn.textContent = t;

  nn.classList.add("animate");

  Telegram.WebApp.HapticFeedback.notificationOccurred(
    n == true ? "success" : "error"
  );
}


function getTotal() {
  const currentTime = Date.now();
  let elapsedTimeInHours = (currentTime - lastTimeMined) / (1000 * 60 * Number(mins));

  elapsedTimeInHours = Math.min(elapsedTimeInHours, 1);

  const t = elapsedTimeInHours * earningsPerHour;
  return t;
}

async function claimEarnings() {
  if (earningsPerHour == 0) {
    notify(false, "Please deposit to activate a miner!");
    return;
  }
  const n = getTotal();

  if (n >= earningsPerHour) {
    try {
      notify(true, "Claiming...");
      const gg = await axios.get("/claim");
      const r = gg.data;

      if (r.suc) {
        lastTimeMined = r.ll;
        document.querySelector("#ee2").textContent = `$${r.tt}`;
        document.querySelector("#bal").textContent = `${r.bb}`;
        document.querySelector("#ghs").textContent = "0 GH/s ⚡️";
        notify(true, "Claimed Successfully!");
      } else {
        notify(false, "You cant claim less than " + earningsPerHour + " USDT!");
      }
    } catch (e) {
      console.log(e);
      notify(false, "Oops! Sorry, An error occured, please try again later!");
    }
  } else {
    notify(false, "You cant claim less than " + earningsPerHour + " USDT!");
  }
}

setInterval(async () => {
  try {
    const response = await axios.get("/bs");

    if (response.status === 200) {
      const d = response.data;
      if (d.success && d.success == false) {
        return;
      }
      const { type, from, to, value, hash } = d;
      const hashLink = `<a class="hash-link" href="https://tronscan.org/#/transaction/${hash}" target="_blank">${hash.slice(
        0,
        12
      )}...</a>`;

      dd.innerHTML = `New ${type} from ${from.slice(0,7)}, hash, ${hashLink}`;
      dd.classList.add("animateDatas");
      dd.classList.remove("removeDatas");

      setTimeout(() => {
        dd.classList.add("removeDatas");
        dd.classList.remove("animateDatas");
      }, 3000);
    }
  } catch (e) {
    console.log(e);
  }
}, 5000);

const intId = setInterval(() => {
  const newMine = getTotal();
  let p = (newMine / earningsPerHour) * 100;
  p = Math.min(p);

  document.querySelector(".mining-value").textContent =
    newMine.toFixed(10) + " USDT";

  document.querySelector("#progress-fill").style.width = `${
    p >= 100 ? 100 : p
  }%`;

  if (p >= 100) {
    document.querySelector("#progress-fill").style.backgroundColor =
      "rgb(140, 9, 9)";
  }

  if (newMine >= earningsPerHour) {
    clearInterval(intId);
  }
}, 50);

